plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.k8voicestudio.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.k8voicestudio.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0"
    }
}

dependencies {
    // RNNoise-based recurrent-neural-network denoiser; runs locally on-device.
    implementation("com.github.rizukirr.audx-android:audx:3.0.0")
}
