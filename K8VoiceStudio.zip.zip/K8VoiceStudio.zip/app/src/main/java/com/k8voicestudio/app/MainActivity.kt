package com.k8voicestudio.app

import android.Manifest
import android.app.Activity
import android.content.ContentValues
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.SeekBar
import android.media.MediaPlayer
import android.os.Handler
import android.os.Looper
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.audx.android.Audx
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread

/**
 * K8 Voice Studio: offline recorder with an RNNoise-based denoiser.
 * Keeps both raw and cleaned WAV files so the original voice is never lost.
 */
class MainActivity : Activity() {
    private val sampleRate = 48_000
    private val frameSamples = 480 // 10 ms at 48 kHz
    private val recording = AtomicBoolean(false)
    private var recorder: AudioRecord? = null
    private var denoiser: Audx? = null
    private var rawOut: OutputStream? = null
    private var cleanOut: OutputStream? = null
    private var rawFile: File? = null
    private var cleanFile: File? = null
    private lateinit var status: TextView
    private lateinit var recordButton: Button
    private lateinit var saveButton: Button
    private lateinit var hint: TextView
    private lateinit var timerText: TextView
    private lateinit var aiToggle: CheckBox
    private lateinit var playRawButton: Button
    private lateinit var playCleanButton: Button
    private lateinit var stopPlaybackButton: Button
    private var mediaPlayer: MediaPlayer? = null
    private var startedAt = 0L
    private val mainHandler = Handler(Looper.getMainLooper())
    private val timerTick = object : Runnable {
        override fun run() {
            if (recording.get()) {
                val seconds = ((System.currentTimeMillis() - startedAt) / 1000).toInt()
                timerText.text = "مدة التسجيل: %02d:%02d".format(seconds / 60, seconds % 60)
                mainHandler.postDelayed(this, 500)
            }
        }
    }
    private var lastRaw: File? = null
    private var lastClean: File? = null
    private var rawBytes = 0L
    private var cleanBytes = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 40)
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 24, 22, 24)
            setBackgroundColor(0xFF0B1220.toInt())
        }
        fun label(text: String, size: Float = 15f, color: Int = 0xFFDCE6F7.toInt()) = TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            setPadding(2, 8, 2, 8)
        }
        fun section(text: String) = TextView(this).apply {
            this.text = text
            textSize = 16f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setTextColor(0xFF7DD3FC.toInt())
            setPadding(0, 18, 0, 6)
        }
        fun styledButton(text: String) = Button(this).apply {
            this.text = text
            textSize = 15f
            isAllCaps = false
        }
        root.addView(label("K8 VOICE STUDIO", 26f, 0xFFFFFFFF.toInt()).apply {
            gravity = Gravity.CENTER
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        })
        root.addView(label("مسجل صوت لصنّاع المحتوى • معالجة محلية بدون إنترنت", 14f, 0xFF9FB2CE.toInt()).apply { gravity = Gravity.CENTER })
        status = label("● جاهز للتسجيل • أوفلاين", 16f, 0xFF86EFAC.toInt()).apply {
            gravity = Gravity.CENTER
            setPadding(12, 16, 12, 16)
            setBackgroundColor(0xFF142C2A.toInt())
        }
        root.addView(status)
        timerText = label("مدة التسجيل: 00:00", 16f, 0xFFFFFFFF.toInt()).apply { gravity = Gravity.CENTER }
        root.addView(timerText)
        root.addView(section("إعدادات التسجيل"))
        aiToggle = CheckBox(this).apply {
            text = "تنقية عصبية بالذكاء الاصطناعي (RNNoise)"
            isChecked = true
            textSize = 15f
            setTextColor(0xFFFFFFFF.toInt())
            buttonTintList = android.content.res.ColorStateList.valueOf(0xFF38BDF8.toInt())
        }
        root.addView(aiToggle)
        root.addView(label("بنحفظ الصوت الأصلي دائمًا كنسخة احتياطية. لو التنقية أثرت على صوتك، قارن النسختين واستخدم الأصل.", 13f, 0xFFB5C2D6.toInt()))
        recordButton = styledButton("● ابدأ التسجيل").apply {
            textSize = 18f
            setOnClickListener { if (recording.get()) stopRecording() else startRecording() }
        }
        root.addView(recordButton, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 10 })
        root.addView(section("مراجعة الصوت"))
        playRawButton = styledButton("▶ تشغيل الصوت الأصلي").apply {
            isEnabled = false
            setOnClickListener { playFile(lastRaw, "جاري تشغيل الصوت الأصلي…") }
        }
        playCleanButton = styledButton("▶ تشغيل الصوت المنقّى").apply {
            isEnabled = false
            setOnClickListener { playFile(lastClean, "جاري تشغيل الصوت المنقّى…") }
        }
        stopPlaybackButton = styledButton("■ إيقاف التشغيل").apply {
            isEnabled = false
            setOnClickListener { stopPlayback() }
        }
        root.addView(playRawButton)
        root.addView(playCleanButton)
        root.addView(stopPlaybackButton)
        saveButton = styledButton("حفظ النسختين في Downloads").apply {
            isEnabled = false
            setOnClickListener { exportLastFiles() }
        }
        root.addView(saveButton, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 8 })
        root.addView(section("نصائح لأفضل نتيجة"))
        hint = label("""• وصّل K8 قبل فتح التطبيق.
• خليك على بُعد 10–15 سم من المايك، وتكلم بوضوح من غير ما تصرخ.
• جرّب تسجيل 10 ثوانٍ في مكان هادي وقارن الأصل بالمنقّى.
• التنقية تقلل ضوضاء الخلفية، لكنها لا تصلح التكسير الناتج عن مستوى إدخال مرتفع جدًا.
• التطبيق لا يرفع صوتك إلى أي خادم؛ المعالجة تتم على الهاتف.""", 14f, 0xFFB5C2D6.toInt())
        root.addView(hint)
        root.addView(label("الإصدار 1.0 • WAV / PCM 16-bit • Mono 48 kHz", 12f, 0xFF7185A5.toInt()).apply { gravity = Gravity.CENTER })
        val scroll = ScrollView(this).apply { addView(root) }
        setContentView(scroll)
    }

    private fun playFile(file: File?, message: String) {
        if (recording.get()) { toast("أوقف التسجيل الأول"); return }
        if (file == null || !file.exists()) { toast("التسجيل مش موجود"); return }
        stopPlayback()
        try {
            mediaPlayer = MediaPlayer().apply {
                setDataSource(file.absolutePath)
                setOnCompletionListener {
                    stopPlayback()
                    status.text = "انتهى تشغيل الملف • جاهز"
                }
                prepare()
                start()
            }
            stopPlaybackButton.isEnabled = true
            status.text = message
        } catch (e: Exception) {
            stopPlayback()
            toast("تعذر تشغيل الملف: ${e.message ?: "خطأ"}")
        }
    }

    private fun stopPlayback() {
        try { mediaPlayer?.stop() } catch (_: Exception) {}
        try { mediaPlayer?.release() } catch (_: Exception) {}
        mediaPlayer = null
        if (::stopPlaybackButton.isInitialized) stopPlaybackButton.isEnabled = false
    }

    private fun startRecording() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 40)
            return
        }
        val minBuffer = AudioRecord.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (minBuffer <= 0) {
            toast("الجهاز مش قادر يفتح تسجيل 48kHz؛ جرّب جهاز تاني أو إعداد مختلف.")
            return
        }
        try {
            val dir = getExternalFilesDir(Environment.DIRECTORY_MUSIC) ?: filesDir
            if (!dir.exists()) dir.mkdirs()
            val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            rawFile = File(dir, "K8_original_$stamp.wav")
            cleanFile = File(dir, "K8_clean_$stamp.wav")
            rawBytes = 0
            cleanBytes = 0
            rawOut = BufferedOutputStream(FileOutputStream(rawFile!!))
            cleanOut = BufferedOutputStream(FileOutputStream(cleanFile!!))
            writeWavHeader(rawOut!!, sampleRate, 0)
            writeWavHeader(cleanOut!!, sampleRate, 0)
            denoiser = if (aiToggle.isChecked) Audx.Builder().inputRate(sampleRate).resampleQuality(Audx.AUDX_RESAMPLER_QUALITY_VOIP).build() else null
            recorder = AudioRecord(
                MediaRecorder.AudioSource.MIC,
                sampleRate,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                maxOf(minBuffer, frameSamples * 8)
            )
            if (recorder?.state != AudioRecord.STATE_INITIALIZED) throw IllegalStateException("AudioRecord init failed")
            recorder?.startRecording()
            recording.set(true)
            recordButton.text = "■ إيقاف التسجيل"
            saveButton.isEnabled = false
            startedAt = System.currentTimeMillis()
            mainHandler.post(timerTick)
            status.text = if (aiToggle.isChecked) "جاري التسجيل والتنقية العصبية محليًا…" else "جاري التسجيل بدون تنقية…"
            status.setTextColor(0xFF9A3412.toInt())
            thread(name = "K8AudioCapture") { captureLoop() }
        } catch (e: Exception) {
            recording.set(false)
            cleanupAudio()
            toast("تعذر بدء التسجيل: ${e.message ?: "خطأ غير معروف"}")
            status.text = "تعذر بدء التسجيل"
        }
    }

    private fun captureLoop() {
        val input = ShortArray(maxOf(frameSamples * 8, AudioRecord.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)))
        val frame = ShortArray(frameSamples)
        val processed = ShortArray(frameSamples)
        var pending = 0
        try {
            while (recording.get()) {
                val n = recorder?.read(input, 0, input.size, AudioRecord.READ_BLOCKING) ?: break
                if (n <= 0) continue
                synchronized(this) {
                    rawOut?.let { writeShorts(it, input, n); rawBytes += n * 2L }
                }
                var i = 0
                while (i < n) {
                    val take = minOf(frameSamples - pending, n - i)
                    System.arraycopy(input, i, frame, pending, take)
                    pending += take
                    i += take
                    if (pending == frameSamples) {
                        val d = denoiser
                        if (d != null) {
                            d.process(frame, processed) { _ -> }
                        } else {
                            System.arraycopy(frame, 0, processed, 0, frame.size)
                        }
                        synchronized(this) {
                            cleanOut?.let { writeShorts(it, processed, processed.size); cleanBytes += processed.size * 2L }
                        }
                        pending = 0
                    }
                }
            }
        } catch (_: Exception) {
            // Keep any successfully recorded audio and close files safely below.
        } finally {
            synchronized(this) {
                // A partial last frame is copied unchanged rather than discarded or aggressively denoised.
                if (pending > 0) {
                    cleanOut?.let { writeShorts(it, frame, pending); cleanBytes += pending * 2L }
                }
                try { rawOut?.flush() } catch (_: Exception) {}
                try { cleanOut?.flush() } catch (_: Exception) {}
                try { rawOut?.close() } catch (_: Exception) {}
                try { cleanOut?.close() } catch (_: Exception) {}
                rawOut = null
                cleanOut = null
                rawFile?.let { patchWavHeader(it, rawBytes) }
                cleanFile?.let { patchWavHeader(it, cleanBytes) }
                lastRaw = rawFile
                lastClean = cleanFile
            }
            cleanupAudio()
            runOnUiThread {
                mainHandler.removeCallbacks(timerTick)
                timerText.text = "مدة التسجيل: %02d:%02d".format(((System.currentTimeMillis() - startedAt) / 60000).toInt(), (((System.currentTimeMillis() - startedAt) / 1000) % 60).toInt())
                recordButton.text = "● ابدأ التسجيل"
                saveButton.isEnabled = lastRaw?.exists() == true && lastClean?.exists() == true
                playRawButton.isEnabled = lastRaw?.exists() == true
                playCleanButton.isEnabled = lastClean?.exists() == true
                status.text = "انتهى التسجيل • تم حفظ الأصل والمنقّى"
                status.setTextColor(0xFF146B4A.toInt())
            }
        }
    }

    private fun stopRecording() {
        if (!recording.getAndSet(false)) return
        status.text = "جاري إنهاء الملفات…"
        recordButton.isEnabled = false
        thread {
            try { recorder?.stop() } catch (_: Exception) {}
            runOnUiThread { recordButton.isEnabled = true }
        }
    }

    private fun cleanupAudio() {
        try { recorder?.release() } catch (_: Exception) {}
        recorder = null
        try { denoiser?.close() } catch (_: Exception) {}
        denoiser = null
    }

    private fun writeShorts(out: OutputStream, data: ShortArray, count: Int) {
        val bytes = ByteArray(count * 2)
        for (i in 0 until count) {
            val v = data[i].toInt()
            bytes[i * 2] = (v and 0xff).toByte()
            bytes[i * 2 + 1] = ((v shr 8) and 0xff).toByte()
        }
        out.write(bytes)
    }

    private fun writeWavHeader(out: OutputStream, rate: Int, dataSize: Long) {
        val h = wavHeader(rate, dataSize)
        out.write(h)
    }

    private fun wavHeader(rate: Int, dataSize: Long): ByteArray {
        val total = dataSize + 36
        val b = ByteArray(44)
        fun ascii(s: String, start: Int) { s.toByteArray(Charsets.US_ASCII).copyInto(b, start) }
        fun le16(v: Int, p: Int) { b[p] = v.toByte(); b[p + 1] = (v shr 8).toByte() }
        fun le32(v: Long, p: Int) { for (i in 0..3) b[p + i] = (v shr (8 * i)).toByte() }
        ascii("RIFF", 0); le32(total, 4); ascii("WAVE", 8); ascii("fmt ", 12)
        le32(16, 16); le16(1, 20); le16(1, 22); le32(rate.toLong(), 24)
        le32((rate * 2L), 28); le16(2, 32); le16(16, 34); ascii("data", 36); le32(dataSize, 40)
        return b
    }

    private fun patchWavHeader(file: File, dataSize: Long) {
        try {
            java.io.RandomAccessFile(file, "rw").use { raf ->
                raf.seek(0); raf.write(wavHeader(sampleRate, dataSize))
            }
        } catch (_: Exception) {}
    }

    private fun exportLastFiles() {
        val raw = lastRaw
        val clean = lastClean
        if (raw == null || clean == null || !raw.exists() || !clean.exists()) {
            toast("مفيش تسجيل محفوظ لسه")
            return
        }
        try {
            val resolver = contentResolver
            val rawValues = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, raw.name)
                put(MediaStore.Downloads.MIME_TYPE, "audio/wav")
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val cleanValues = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, clean.name)
                put(MediaStore.Downloads.MIME_TYPE, "audio/wav")
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val rawUri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, rawValues)
            val cleanUri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cleanValues)
            if (rawUri != null) resolver.openOutputStream(rawUri)?.use { raw.inputStream().use { src -> src.copyTo(it) } }
            if (cleanUri != null) resolver.openOutputStream(cleanUri)?.use { clean.inputStream().use { src -> src.copyTo(it) } }
            rawValues.clear(); rawValues.put(MediaStore.Downloads.IS_PENDING, 0)
            cleanValues.clear(); cleanValues.put(MediaStore.Downloads.IS_PENDING, 0)
            if (rawUri != null) resolver.update(rawUri, rawValues, null, null)
            if (cleanUri != null) resolver.update(cleanUri, cleanValues, null, null)
            toast("اتحفظت نسختين في مجلد Downloads: الأصلية والمنقّاة")
        } catch (e: Exception) {
            toast("تعذر التصدير: ${e.message ?: "خطأ"}")
        }
    }

    private fun toast(message: String) = runOnUiThread { Toast.makeText(this, message, Toast.LENGTH_LONG).show() }

    override fun onDestroy() {
        mainHandler.removeCallbacks(timerTick)
        stopPlayback()
        if (recording.get()) stopRecording()
        super.onDestroy()
    }
}
